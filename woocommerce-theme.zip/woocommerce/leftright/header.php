<!DOCTYPE html>
<head>
    <meta charset="utf-8">
    <title>商品 | WeiXin</title>
    <meta name="viewport" content="width=device-width,user-scalable=no" />
    <link rel="stylesheet" type="text/css" href="http://apps.bdimg.com/libs/blendui/2.0-alpha/blendui.min.css" />
    <script type="text/javascript" src="http://apps.bdimg.com/libs/blendui/2.0-alpha/blendui.min.js"></script>
    <?php wp_head(); ?>
</head>
<body>